//
//  ALU.hpp
//  ArchiProj
//
//  Created by Mostafa Henna on 11/30/17.
//  Copyright © 2017 Mostafa Henna. All rights reserved.
//

#ifndef ALU_h
#define ALU_h

#include <stdio.h>
#include <string>

class ALU
{

public:
	ALU();
	void EX(bool &, bool, int, int, int,int,int &);
};
#endif /* ALU_h */