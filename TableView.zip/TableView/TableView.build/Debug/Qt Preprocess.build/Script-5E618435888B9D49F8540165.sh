#!/bin/sh
make -C '/Users/asserhangal/Qt Projects/TableView/' -f TableView.xcodeproj/qt_makeqmake.mak
